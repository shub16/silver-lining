import wx
import os

# Toolkit Chooser made in wxPython
class MyFrame(wx.Frame):
    def __init__(self, parent, id, title):
        wx.Frame.__init__(self, parent, id, title, (-1, -1), wx.Size(300, 300))
        
        panel = wx.Panel(self, -1)
        panel.SetBackgroundColour("#770000")
        
        box = wx.BoxSizer(wx.VERTICAL)
        
        button1 = wx.Button(panel, -1, 'wxPython') 
        button2 = wx.Button(panel, -2, 'pyqt') 
        button3 = wx.Button(panel, -3, 'pytk') 
	button4 = wx.Button(panel, -4, 'pygtk')
        button5 = wx.Button(panel, -5, 'exit') 
        
        box.Add(button1, 1, wx.EXPAND | wx.ALL,10 )
        box.Add(button2, 1, wx.EXPAND | wx.ALL,10 )
        box.Add(button3, 1, wx.EXPAND | wx.ALL,10 )
        box.Add(button4, 1, wx.EXPAND | wx.ALL,10 )
        box.Add(button5, 1, wx.EXPAND | wx.ALL,10 )

        self.Bind(wx.EVT_BUTTON, self.OnClickbut1, id=button1.GetId())
        self.Bind(wx.EVT_BUTTON, self.OnClickbut2, id=button2.GetId())
        self.Bind(wx.EVT_BUTTON, self.OnClickbut3, id=button3.GetId())
        self.Bind(wx.EVT_BUTTON, self.OnClickbut4, id=button4.GetId())
        self.Bind(wx.EVT_BUTTON, self.OnClickbut5, id=button5.GetId())
        
        panel.SetSizer(box)
        self.Centre()
        self.Show(True)
        
        
    def OnClickbut1(self, event):
        os.chdir("./AnyGUI")
	os.system("python wxGUI.py")
	os.chdir("..")
       
    def OnClickbut2(self, event):
	os.chdir("./AnyGUI")
	os.system("python qtGUI.py")
	os.chdir("..")
        
    def OnClickbut3(self, event):
	os.chdir("./AnyGUI")
	os.system("python tkGUI.py")
	os.chdir("..")

    def OnClickbut4(self,event):
	os.chdir("./AnyGUI")
	os.system("python gtkGUI.py")
	os.chdir("..")

    def OnClickbut5(self,event):
	self.Close()

if __name__ == '__main__':
        
         app=wx.App()   
         frame = MyFrame(None, -1, 'Select Your GUI | wxPython')
         app.MainLoop()
