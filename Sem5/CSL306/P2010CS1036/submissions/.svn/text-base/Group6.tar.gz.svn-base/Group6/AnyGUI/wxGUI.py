import wx

''' WX_Main_Window : On it widget can be add_widgeted '''
class Main_Window(wx.Frame):
    parent = None
    Type = "Main_Window"
    def __init__(self, id, title,width,height):
        self.app = wx.App(False)
        wx.Frame.__init__(self, self.parent, id, title, wx.DefaultPosition, wx.Size(width, height))
        self.panel = wx.Panel(self, -1)


    def show(self):
        self.Show(True)
        self.Centre()
        self.app.MainLoop()
        return


    def add_widget(self,widget):
        widget_type = type(widget)

        if(widget_type==TextBox or isinstance(widget,TextBox)):
            widget.instance = wx.TextCtrl(self.panel, -1, widget.text,  widget.position, widget.size, style=wx.TE_MULTILINE)
        
	elif(widget_type==TextField or isinstance(widget,TextField)):
            widget.instance = wx.TextCtrl(self.panel, -1, widget.text,  widget.position, widget.size)

	elif(widget_type==TextFieldPass or isinstance(widget,TextFieldPass)):
            widget.instance = wx.TextCtrl(self.panel, -1, widget.text,  widget.position, widget.size, style = wx.TE_PASSWORD)
    
        elif(widget_type==Button or isinstance(widget,Button)):
            widget.instance = wx.Button(self.panel, -1, widget.title,  widget.position, widget.size)
            if(widget.callbackMethod != None ):
                widget.instance.Bind(wx.EVT_BUTTON, widget.callbackMethod)

        elif(widget_type==CheckBox or isinstance(widget,CheckBox)):
            widget.instance = wx.CheckBox(self.panel, -1, widget.title,  widget.position,widget.size)
            widget.instance.SetValue(widget.value)

        elif(widget_type==RadioButtons or isinstance(widget,RadioButtons)):
            widget.instance = []
            radio_instance = wx.RadioButton(self.panel, -1, widget.labels[0], widget.positions[0],widget.size,style=wx.RB_GROUP)
            widget.instance.append(radio_instance)
            for i in range(1,len(widget.labels)):
                radio_instance = wx.RadioButton(self.panel, -1, widget.labels[i], widget.positions[i],widget.size)
                widget.instance.append(radio_instance)
        
            if(widget.selected_index != None):
                widget.instance[widget.selected_index].SetValue(True)

        elif(widget_type==LabelText or isinstance(widget,LabelText)):
            widget.instance = wx.StaticText(self.panel, -1,widget.text,widget.position,widget.size)

        elif(widget_type==ValueList or isinstance(widget,ValueList)):
            widget.instance = wx.ComboBox(self.panel, -1,widget.value,widget.position,widget.size,widget.choices,style=wx.CB_READONLY)

        elif(widget_type==Slider or isinstance(widget,Slider)):
            widget.instance = wx.Slider(self.panel, -1,minValue=widget._from, maxValue=widget._to, pos=widget.position, size=widget.size,  style=wx.SL_HORIZONTAL) 

	elif(widget_type==SpinBox or isinstance(widget,SpinBox)):
	    widget.instance = wx.SpinCtrl(self.panel,-1,size = widget.size,pos = widget.position, style=wx.SP_HORIZONTAL)
	    widget.instance.SetRange(widget.start, widget.end)


class Widget:
    pass



''' WIDGETS: TextBox '''
class TextBox(wx.TextCtrl):
    instance = None
    def __init__(self,text,X,Y,width,height):
        self.text = text
        self.position = (X,Y)
        self.size = wx.Size(width, height)

    def setText(self,text):
        if(self.instance == None):
            self.text = text
        else:
            self.instance.SetValue(text)
        return True

    def getText(self):
        if(self.instance == None):
            return self.text
        else:
            return self.instance.GetValue()

    def clear(self):
        self.instance.Clear()
        return True

class LabelText(wx.StaticText):						# Labeltext
    instance = None
    def __init__(self,text,X,Y,width,height):
        self.text = text
        self.position = (X,Y)
        self.size = wx.Size(width, height)

class TextFieldPass(wx.TextCtrl):
    instance = None
    def __init__(self,text,X,Y,width,height):
        self.text = text
        self.position = (X,Y)
        self.size = wx.Size(width, -1)

    def setText(self,text):
        if(self.instance == None):
            self.text = text
        else:
            self.instance.SetValue(text)
        return True

    def getText(self):
        if(self.instance == None):
            return self.text
        else:
            return self.instance.GetValue()

class TextField(wx.TextCtrl):						# TextField
    instance = None
    def __init__(self,text,X,Y,width,height):
        self.text = text
        self.position = (X,Y)
        self.size = wx.Size(width, -1)

    def setText(self,text):
        if(self.instance == None):
            self.text = text
        else:
            self.instance.SetValue(text)
        return True

    def getText(self):
        if(self.instance == None):
            return self.text
        else:
            return self.instance.GetValue()

storePass = "oldpassword"						# Rent Secure
secure = True

def rentSecure(password,isSecure):
    if(isSecure):
        for i in range(len(password)):
           password = password.replace(password[i],"*")
    print isSecure,password
    return password

def Submit(self):							# Submit
    newps1 = NewPstb.getText();
    newps2 = ReNewPstb.getText();
    if(IsValidPswd(newps1,newps2)):
        print (" Password Successfully Changed ! ");
        OldPstb.setText("");
        NewPstb.setText("");
        ReNewPstb.setText("");
    else:
        print (" Retry by Entering new Password!  ");
        OldPstb.setText("");
        NewPstb.setText("");
        ReNewPstb.setText("");

def IsValidPswd(newps1, newps2):						# Is valid Password
    if newps1 != newps2:
       print(" Password Error !  Passwords donot match! ")
       return False
    
    if(len(newps1)<=6):               # Check the length of the password
       print(" Password Error ! Password Length should be more than 6. ")
       return False    
    
    if(str(newps1).isalnum()):             #checks if password conatins only alpha or numeric fiels
        
        if(str(newps1).isalpha()):          # invalidates if  password contains only alphabets not a combination.
            print(" Password Error ! Password cannot be only alphabet.Try combination! ")
            return False   
        
        elif(str(newps1).isdigit()):	    #Invalidates if password contains only digits not a combination.
            print(" Password Error ! Password cannot be only digit.Try combination! ")
            return False
        
        else :			                     
            print ("Password Successfully Changed. !");
            return True
    else:                                            # Invalidates if password have non-alphanumeric characters.
       print (" Password Error ! Password should contain only alphabets and digits.");
       return False



''' WIDGETS: Button '''
class Button(wx.Button):
    instance = None
    callbackMethod = None
    def __init__(self,title,X,Y,width,height):
        self.title = title
        self.position = (X,Y)
        self.size = wx.Size(width, height)

    def on_click(self,method):
        if(self.instance == None):
            self.callbackMethod = method
        else:
            self.instance.Bind(wx.EVT_BUTTON, method)
        return True

class ValueList(wx.ComboBox):
    instance = None
    def __init__(self,choices,X,Y,width,height,value=""):
        self.choices = choices
        self.position = (X,Y)
        self.size = (width,-1)
        self.value = value

    def getValue(self):
            if(self.instance == None):
                return self.value
            else:
                return self.instance.GetValue()


''' WIDGETS: CheckBox '''
class CheckBox(wx.CheckBox):
    instance = None
    value = False
    def __init__(self,title,X,Y,width,height):
        self.title = title
        self.position = (X,Y)
        self.size = wx.Size(width, height)

    def set_state(self,value):
        if(self.instance == None):
            self.value = value
        else:
            self.instance.SetValue(value)

    def get_state(self):
        if(self.instance == None):
            return self.value
        else:
            return self.instance.IsChecked()

''' WIDGETS: Slider '''
class Slider(wx.Slider):
    instance = None
    def __init__(self,_from,_to,X,Y,width,height):
        self.position = (X,Y)
        self.size = wx.Size(width, height)
        self._from = _from
        self._to = _to

    def getValue(self):
        return self.instance.GetValue()

class SpinBox(wx.SpinCtrl):
    instance = None

    def __init__(self,start,end,X,Y,width,height):
	self.position = (X,Y)
	self.size = wx.Size(width,height)
	self.start = start
	self.end = end

    def getValue(self):
	return self.instance.GetValue()

''' WIDGETS: RadioButtons '''
class RadioButtons(wx.RadioButton):
    instance = None
    selected_index = None
    def __init__(self,width,height):
        self.labels = []
        self.positions = []
        self.size = wx.Size(width, height)

    def add_radiobutton(self,label,X,Y):
        self.labels.append(label)
        self.positions.append((X,Y))
        return True

    def get_state(self):
        for i in range(len(self.instance)):
            if(self.instance[i].GetValue()):
                return self.labels[i]
        return None

if __name__ == '__main__':
	def SubmitButtonClick(event=None):

	    hobbies_temp = "Your hobbies are the following:"
	    hobbies = ""
	    h_list = []
	    h_count = 0

	    if(checkbox11.get_state()):
		hobbies = hobbies + "You like Swimming\n"
		h_list = h_list + ["Swimming"]
		h_count = h_count + 1

	    if(checkbox12.get_state()):
		hobbies = hobbies + "You like Football\n"
		h_list = h_list + ["Football"]
		h_count = h_count + 1

	    if(checkbox13.get_state()):
		hobbies = hobbies + "You like Cycling\n"
		h_list = h_list + ["Cycling"]
		h_count = h_count + 1

	    if(checkbox14.get_state()):
		hobbies = hobbies + "You like Coding :P\n"
		h_list = h_list + ["Coding"]
		h_count = h_count + 1

	    if(checkbox15.get_state()):
		hobbies = hobbies + "You like Jogging\n"
		h_list = h_list + ["Jogging"]
		h_count = h_count + 1

	    if(checkbox16.get_state()):
		hobbies = hobbies + "You like Chatting :)\n"
		h_list = h_list + ["Chatting"]
		h_count = h_count + 1



	    skills_temp = "You are comfortable with the following languages:"
	    skills = ""
	    skill_list = []
	    skill_count = 0;

	    if(checkbox1.get_state()):
		skills = skills + "You like Java\n"
		skill_list = skill_list + ["Java"]    
	    	skill_count = skill_count + 1;
	    
	    if(checkbox2.get_state()):
		skills = skills + "You like C\n"
		skill_list = skill_list + ["C"]    
	    	skill_count = skill_count + 1;

	    if(checkbox3.get_state()):
		skills = skills + "You like C++\n"
		skill_list = skill_list + ["C++"]    
	    	skill_count = skill_count + 1;

	    if(checkbox4.get_state()):
		skills = skills + "You like Python\n"
		skill_list = skill_list + ["Python"]    
	    	skill_count = skill_count + 1;

	    if(checkbox5.get_state()):
		skills = skills + "You like Objective C\n"
		skill_list = skill_list + ["Obejective C"]    
	    	skill_count = skill_count + 1;

	    if(checkbox6.get_state()):
		skills = skills + "You like Ruby :)\n"
		skill_list = skill_list + ["Ruby"]    
	    	skill_count = skill_count + 1;

	
	    Student_Name = name.getText()
	    Student_Rollno = rollno.getText()

	 
	    Gender = rb1.get_state()
	    Department = rb2.get_state()

	    Year = valuelist.getValue()
	    CG = str(CGPA.getValue())
	    per = str(marks.getValue())

	    textarea.setText("Name : " +Student_Name+"\n"+"Entry No :"+Student_Rollno+"\n"+"Year : "+Year+"\n"+"Gender :"+Gender+"\n"+ "Programming Skills :"+"\n"+skills+"\n"+"Hobbies :"+"\n"+hobbies+"\n"+"Department : "+Department+"\n"+"CGPA :"+CG+"\n"+"Marks : "+per)

	    if(Year == "First Year"):
		cv_yr = "1st"
		sem = "1"
	    elif(Year == "Second Year"):
		cv_yr = "2nd"
		sem = "3"
	    elif(Year == "Third Year"):
		sem = "5"
		cv_yr = "3rd"
	    elif(Year == "Fourth Year"):
		sem = "7"
		cv_yr = "4th"

	    skill_str = ""
	    hobby_str = ""

	    for i in range(0,skill_count):
		skill_str = skill_str + "\t* "+skill_list[i]+"\n"

	    for i in range(0,h_count):
		hobby_str = hobby_str + "\t* "+h_list[i]+"\n"

	    cv = Student_Name+"\t\t\t\t"+"Entry No.: "+Student_Rollno+"\n"+Gender+", "+cv_yr+" "+Department+"\t\t"+per+"% in 12th Standard"+ "\n-----------------------------------------------------------------\n"+"\nSecured a CGPA of "+CG+"/10 in "+sem+" semesters\n"+"\n\nProgramming Skills:"+"\n"+skill_str+"\n"+"Co-curriculars:"+"\n"+hobby_str

	    filename = "Resume-"+Student_Name+".txt"
	    cv_file = open('../'+filename,'w')
	    cv_file.write(cv)
	    cv_file.close()
	    return True

	#Constructor canvas
	canvas = Main_Window(1, 'Common API | wxPython - Jag Ustit Singh' ,510,670)




	label_name = LabelText("Name:",30,40,60,40)
	name = TextField("",100,40,120,40)
	canvas.add_widget(label_name)
	canvas.add_widget(name)

	label_rollno = LabelText("Entry No:",270,40,80,40)
	rollno = TextField("",360,40,120,40)
	canvas.add_widget(label_rollno)
	canvas.add_widget(rollno)


	year = ['First Year', 'Second Year', 'Third Year', 'Fourth Year']
	valuelist = ValueList(year,20,100,200,20,"Select your year")
	canvas.add_widget(valuelist)


	rb1 = RadioButtons(90,20)
	rb1.add_radiobutton("Male",350,100)
	rb1.add_radiobutton("Female",350,120)
	canvas.add_widget(rb1)




	label_skills = LabelText("PROGRAMMING SKILLS :",20,150,190,40)
	canvas.add_widget(label_skills)


	checkbox1 = CheckBox("Java",20,190,215,20)
	checkbox2 = CheckBox("C",20,215,215,20)
	checkbox3 = CheckBox("C++",20,240,215,20)
	checkbox4 = CheckBox("Python",20,265,215,20)
	checkbox5 = CheckBox("Objective C",20,290,215,20)
	checkbox6 = CheckBox("Ruby",20,315,215,20)


	canvas.add_widget(checkbox1)
	canvas.add_widget(checkbox2)
	canvas.add_widget(checkbox3)
	canvas.add_widget(checkbox4)
	canvas.add_widget(checkbox5)
	canvas.add_widget(checkbox6)


	label_hobbies = LabelText("HOBBIES :",280,150,190,40)
	canvas.add_widget(label_hobbies)

	checkbox11 = CheckBox("Swimming",280,190,215,20)
	checkbox12 = CheckBox("Football",280,215,215,20)
	checkbox13 = CheckBox("Cycling",280,240,215,20)
	checkbox14 = CheckBox("Coding :P",280,265,215,20)
	checkbox15 = CheckBox("Jogging",280,290,215,20)
	checkbox16 = CheckBox("Chatting :)",280,315,215,20)


	canvas.add_widget(checkbox11)
	canvas.add_widget(checkbox12)
	canvas.add_widget(checkbox13)
	canvas.add_widget(checkbox14)
	canvas.add_widget(checkbox15)
	canvas.add_widget(checkbox16)

	label_CGPA = LabelText("CGPA ",20,380,60,50)
	CGPA =  SpinBox(0.0,10.0,70,380,80,30)
	canvas.add_widget(label_CGPA)
	canvas.add_widget(CGPA)

	label_marks = LabelText("12th Marks:",20,485,90,50)
	marks=Slider(0,100,120,470,200,50)
	canvas.add_widget(label_marks)
	canvas.add_widget(marks)


	label_department = LabelText("DEPARTMENT :",280,370,190,40)
	canvas.add_widget(label_department)


	rb2 = RadioButtons(150,20)
	rb2.add_radiobutton("Mechanical",280,410)
	rb2.add_radiobutton("Electrical",280,430)
	rb2.add_radiobutton("Computer Science",280,450)
	canvas.add_widget(rb2)


	label_name = LabelText("GENDER :",280,90,70,40)
	canvas.add_widget(label_name)


	textarea = TextBox("Please select the appropriate options and then press the evaluate button.You may also enter text here.",120,520,220,130)
	canvas.add_widget(textarea)

	submitBtn = Button("Evaluate",360,620,120,30)
	submitBtn.on_click(SubmitButtonClick)

	canvas.add_widget(submitBtn)

	canvas.show()

