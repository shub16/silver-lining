#! /usr/bin/python

import sys
from PyQt4 import QtGui, QtCore
from functools import partial

class Label(QtGui.QLabel):

    def __init__(self, x, y, name, parent):
        super(Label, self).__init__(parent)
        self.setText(name)
        self.move(x,y)
        
class TextArea(QtGui.QTextEdit):

    def __init__(self,x, y, height, width, name, parent):
        super(TextArea, self).__init__(parent)
        self.setGeometry(x,y,width,height)

class TextLine(QtGui.QLineEdit):

    def __init__(self, x, y, height, width, mode, name, parent):
        super(TextLine, self).__init__(parent)
        
        if mode == "Normal" or mode =="normal":
            self.setEchoMode(self.Normal)
        elif mode == "Password" or mode =="password":
            self.setEchoMode(self.Password)
        elif mode == "NoEcho" or mode =="noecho":
            self.setEchoMode(self.NoEcho)
        elif mode == "PasswordEchoOnEdit":
            self.setEchoMode(self.PasswordEchoOnEdit)
            
        self.setGeometry(x,y,height,width)

    def setValue(self, text):
        self.setText(text)

    def getValue(self):
        text = self.text()
        return text
        

class Button(QtGui.QPushButton):

    def __init__(self, x, y, height, width, name, mode, parent):
        super(Button, self).__init__(name,parent)
        if mode == 1:
            self.setGeometry(x,y,height,width)
        if mode == 2:
            self.setCheckable(True)
            self.setChecked(True)
            self.setGeometry(x,y,height,width)
        if mode == 2:
            self.setFlat(True)
            self.setGeometry(x,y,height,width)
        else:
            self.setGeometry(x,y,height,width)

    def callback(self,method,List):
        self.clicked.connect(partial(method, List))

class CheckBox(QtGui.QCheckBox):
    
    def __init__(self, x, y, height, width, name, state, parent):
        super(CheckBox,self).__init__(name,parent)
        self.setChecked(state)  
        self.setGeometry(x,y,height,width)

    def clicked(self):
        self.stateChanged.connect(self.changeTitle)

    def triState(self, value):
        self.setTristate(value)

    def changeTitle(self, state):
        print 'change'
        if state == QtCore.Qt.Checked:
            self.setWindowTitle('Check Box in use')
        else:
            self.setWindowTitle('Check Box not used')

class RadioButton(QtGui.QRadioButton):
    
    def __init__(self, x, y, height, width, name, parent):
        super(RadioButton,self).__init__(name,parent)
        self.setChecked(True)
        self.setGeometry(x,y,height,width)

    def changeText(self):
        print 'change'
        if self.isChecked():
            self.setWindowTitle('Radio Button on')
        else:
            self.setWindowTitle('Radio Button off')

class DropDownList(QtGui.QComboBox):

    def __init__(self, x, y, height, width, List, name, parent):
        super(DropDownList, self).__init__(parent)
        for i in List:
            self.addItem(i)
        self.setGeometry(x,y,height,width)

class Calendar(QtGui.QCalendarWidget):

    def __init__(self, x, y, parent, *args):
        super(Calendar,self).__init__(parent)
        self.setGridVisible(True)
        self.move(x,y)
        if len(args) == 2:
            self.resize(250,250)
        '''self.clicked[QtCore.QDate].connect(self.showDate)
        self.lbl = QtGui.QLabel(self)
        date = cal.selectedDate()
        self.lbl.setText(date.toString())
        self.lbl.move(130, 260)'''

    def showDate(self,date):
        self.lbl.setText(date.toString())

class Slider(QtGui.QSlider):
    
    def __init__(self, x, y, height, width, name, mode,minValue, maxValue, orientation, parent):
        super(Slider,self).__init__(parent)
        if orientation == "Horizontal" or orientation == "horizontal":
            self.setOrientation(QtCore.Qt.Horizontal)
        elif orientation == "Vertical" or orientation == "vertical":
            self.setOrientation(QtCore.Qt.Vertical)
        
        self.setRange(minValue, maxValue)
        self.setFocusPolicy(QtCore.Qt.NoFocus)

        if mode == 1:
            self.setTickPosition(self.NoTicks)
        elif mode == 2:
            self.setTickPosition(self.TicksBothSides)
        elif mode == 3:
            self.setTickPosition(self.TicksAbove)
        elif mode == 4:
            self.setTickPosition(self.TicksBelow)
        elif mode == 5:
            self.setTickPosition(self.TicksLeft)
        elif mode == 6:
            self.setTickPosition(self.TicksRight)
        else:
            self.setTickPosition(self.NoTicks)

        self.setGeometry(x,y,height,width)

    def setNumber(self,value):
        self.setValue(value)

    def getValue(self):
        value = self.value()
        return value

class SpinBox(QtGui.QSpinBox):
    def __init__(self,x,y,height,width,name,mode,parent):
        super(SpinBox,self).__init__(parent)

    def Range(self,minVal,maxVal):
        self.setRange(minVal,maxval)

    def setStep(self,step):
        self.setSingleStep(step)

    def Value(value):
        self.setValue(value)

class GroupBox(QtGui.QGroupBox):
    def __init__(self,x,y,height,width,name, parent):
        super(GroupBox,self).__init__(name,parent)
        #self.setGeometry(x,y,height,width)

    def setLayouts(self,layoutStyle,page, *widgets):
        if layoutStyle == "Vertical":
            layout = QtGui.QVBoxLayout(page)
        elif layoutStyle == "Horizontal":
            layout = QtGui.QHBoxLayout(page)
        else:
            layout = QtGui.QVBoxLayout(page)
        for widget in widgets:
            layout.addWidget(widget)
        self.setLayout(layout)

class TabPanel(QtGui.QTabWidget):
    def __init__(self,x,y,height,width,parent):
        super(TabPanel,self).__init__(parent)

    def addPage(self, page, pageName):
        self.addTab(page, pageName)

class Page(QtGui.QWidget):
    def __init__(self,x,y,height,widgth,label,parent):
        super(Page, self).__init__(parent)

    def setLayouts(self,group, *widgets):
        layout = QtGui.QVBoxLayout(self)
        for widget in widgets:
            layout.addWidget(widget)
        group.setLayout(layout)

    def setPage(self, *args):
        mainlayout = QtGui.QVBoxLayout(self)
        for widget in args:
            mainlayout.addWidget(widget)
        mainlayout.addStretch(1)           #SEE THIS LATER COMMENTED BECAUSE WE ARE USING ABSOLUTE POSITIONING
        self.setLayout(mainlayout)

class HorizontalLayout(QtGui.QHBoxLayout):
    def __init__(self,parent):
        super(HorizontalLayout,self).__init__(parent)

    def addWidgets(self, *args):
        for widget in args:
            self.addWidget(widget)

    def stretch(self, value):
        self.addStretch(value)

    def spacing(self, value):
        self.addSpacing(value)
        
    def AddLayout(self, layout):
        self.addLayout(layout)

class VerticalLayout(QtGui.QVBoxLayout):
    def __init__(self,parent):
        super(VerticalLayout,self).__init__(parent)

    def addWidgets(self, *args):
        self.addStretch(1)
        for widget in args:
            self.addWidget(widget)

    def stretch(self, value):
        self.addStretch(value)

    def spacing(self, value):
        self.addSpacing(value)
        
    def addLayouts(self, *layouts):
        for layout in layouts:
            self.addLayout(layout)

class Window(QtGui.QDialog):
    def __init__(self, height, width, title):
        self.app = QtGui.QApplication(sys.argv)
        super(Window, self).__init__()
        self.resize(height, width)
        self.setWindowTitle(title)
        self.center

    def center(self):
        qr = self.frameGeometry()                                   # Getting current window frame of my desktop
        cp = QtGui.QDesktopWidget().availableGeometry().center()    # Getting center point of my Desktop wiondow
        qr.moveCenter(cp)                                           # moving the center of the window to the cp
        self.move(qr.topLeft())

    def displayWindow(self,widget):
        ml = QtGui.QVBoxLayout(self)
        ml.addWidget(widget)
        self.setLayout(ml)
        self.show()
        sys.exit(self.app.exec_())
    
'''class Window(QtGui.QWidget):
    
    def __init__(self, x, y, height, width, title):
        self.app = QtGui.QApplication(sys.argv)
        super(Window, self).__init__()
        self.setGeometry(x, y, height, width)
        self.setWindowTitle(title)
        self.center

    def center(self):
        qr = self.frameGeometry()                                   # Getting current window frame of my desktop
        cp = QtGui.QDesktopWidget().availableGeometry().center()    # Getting center point of my Desktop wiondow
        qr.moveCenter(cp)                                           # moving the center of the window to the cp
        self.move(qr.topLeft())    

    def displayWindow(self):
        self.show()
        sys.exit(self.app.exec_())'''
        
if __name__ == '__main__':
    dw = Window(500,400,"DEMO")
    tabWidget = TabPanel(1,1,700,700,dw)
    
    #TextLine & TextArea Page
    textline_page = Page(1,1,20,20,"AC",tabWidget)
    textline_group = GroupBox(1,1,20,20,"TextLine",textline_page)
    lbl1 = Label(10,10,"Normal Field",textline_page)
    t1 = TextLine(110,10,200, 30,"Normal","Name",textline_page)
    lbl2 = Label(10,10,"Password Field",textline_page)
    t2 = TextLine(110,10,200, 30,"Password","Password",textline_page)
    
    textarea_group = GroupBox(1,1,20,20,"TextArea",textline_page)
    lbl3 = Label(10,10,"Password Field",textline_page)
    t3 = TextArea(110,10,200,30,"Name",textline_page)
    
    textline_group.setLayouts("Vertical",textline_page,lbl1,t1,lbl2,t2)
    textarea_group.setLayouts("Vertical",textline_page,lbl3,t3)
    textline_page.setPage(textline_group,textarea_group)

    #CheckBox Page
    checkbox_page = Page(1,1,20,20,"AC",tabWidget)
    checkbox = GroupBox(50,50,400,400,"UnChecked CheckBoxes", checkbox_page)
    lbl4 = Label(10,10,"Password Field",textline_page)
    c1 = CheckBox(150,100,100,100,"CheckBox1",False,checkbox_page)
    lbl5 = Label(10,10,"Password Field",textline_page)
    c2 = CheckBox(150,200,100,100,"CheckBox2",False,checkbox_page)

    checkbox_group = GroupBox(50,50,400,400,"Checked CheckBoxes", checkbox_page)
    lbl6 = Label(10,10,"Password Field",textline_page)
    c3 = CheckBox(150,100,100,100,"CheckBox1",True,checkbox_page)
    lbl7 = Label(10,10,"Password Field",textline_page)
    c4 = CheckBox(150,200,100,100,"CheckBox2",True,checkbox_page)

    checkbox.setLayouts("Vertical",checkbox_page,c1,c2)
    checkbox_group.setLayouts("Vertical",checkbox_page,c3,c4)
    checkbox_page.setPage(checkbox,checkbox_group)

    #Button Page
    button_page = Page(1,1,20,20,"Button",tabWidget)
    button_group = GroupBox(50,50,400,400,"Buttons",button_page)
    but1 = Button(50,50,100,100,"Normal Button",1,button_page)
    but2 = Button(50,50,100,100,"Toggle Button",2,button_page)
    but3 = Button(50,50,100,100,"Flat Button",3,button_page)
    
    button_group.setLayouts("Vertical",button_page,but1,but2,but3) #Group Layout Setting
    button_page.setPage(button_group) #Page Layout Setting

    #DropDownList Page
    ddl_page = Page(1,1,20,20,"DropDownList",tabWidget)
    ddl_group = GroupBox(50,50,400,400,"DropDownList",ddl_page)
    List = ["a","b","c","d"]
    ddl = DropDownList(50,50,400,400,List,"DropDownList",ddl_page)

    ddl_group.setLayouts("Vertical",ddl_page,ddl)
    ddl_page.setPage(ddl_group)

    #Slider Page
    slider_page = Page(1,1,20,20,"Slider",tabWidget)
    slider_Hgroup = GroupBox(50,50,400,400,"Slider",slider_page)
    slider1= Slider(1,1,20,20,"Slider", 2, 0, 100, "Horizontal", slider_page)
    slider2= Slider(1,1,20,20,"Slider", 3, 0, 200, "Horizontal", slider_page)
    slider3= Slider(1,1,20,20,"Slider", 4, 0, 150, "Horizontal", slider_page)

    slider_Hgroup.setLayouts("Vertical",slider_page,slider1,slider2,slider3)
    
    slider_Vgroup = GroupBox(50,50,400,400,"Slider",slider_page)
    slider4= Slider(1,1,20,20,"Slider", 2, 0, 100, "Vertical", slider_page)
    slider5= Slider(1,1,20,20,"Slider", 5, 0, 100, "Vertical", slider_page)
    slider6= Slider(1,1,20,20,"Slider", 6, 0, 100, "Vertical", slider_page)

    slider_Vgroup.setLayouts("Horizontal",slider_page,slider4,slider5,slider6)
    slider_page.setPage(slider_Hgroup,slider_Vgroup)

    #RadioButton Page
    radio_page = Page(1,1,20,20,"RadioButton",tabWidget)
    radio_group = GroupBox(50,50,400,400,"RadioButton",radio_page)
    rb1 = RadioButton(150,100,100,100,"Radio Button1",radio_page)
    rb2 = RadioButton(150,100,100,100,"Radio Button2",radio_page)
    rb3 = RadioButton(150,100,100,100,"Radio Button3",radio_page)

    radio_group.setLayouts("Vertical",radio_page,rb1,rb2,rb3)
    radio_page.setPage(radio_group)

    #SpinBox Page
    spinbox_page = Page(1,1,20,20,"SpinBox",tabWidget)
    spinbox_group = GroupBox(50,50,400,400,"SpinBox",spinbox_page)
    sb = SpinBox(150,100,100,100,"SpinBox",1,spinbox_page)

    spinbox_group.setLayouts("Vertical",spinbox_page,sb)
    spinbox_page.setPage(spinbox_group)

    tabWidget.addPage(checkbox_page,"CheckBox")
    tabWidget.addPage(textline_page,"TextLine")
    tabWidget.addPage(button_page,"Buttons")
    tabWidget.addPage(ddl_page,"DropDownList")
    tabWidget.addPage(slider_page,"Sliders")
    tabWidget.addPage(radio_page,"Radio Buttons")
    tabWidget.addPage(spinbox_page,"SpinBox")
    
    ''' Layout setting for main display '''
    dw.displayWindow(tabWidget)
