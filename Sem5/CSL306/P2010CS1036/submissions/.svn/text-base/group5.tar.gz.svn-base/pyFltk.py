from fltk import *                                                                                  #importing Fltk
import sys


x_temp=10
y_temp=10
w_temp=500                                                                                          #Widget input variable
h_temp=500

      
class Label():
    
    def __init__(self,*args):
        pass

class TextArea(Fl_Input):

    def __init__(self,x,y,height,width,label,*args):                                                 #constructor of multiline input class
        Fl_Multiline_Input(x,y,height,width, label)
                                



class TextLine(Fl_Secret_Input,Fl_Input):

    def __init__(self,x,y,height,width,mode="",label="",*args):                                     #constructor of Singleline input class with 2 modes                                                          

        if(mode=="Normal"):
            Fl_Input(x,y,height,width, label)

        elif(mode=="Password"):
            Fl_Secret_Input(x,y,height,width, label)                                                #Password textline     

        else:
            Fl_Input(x,y,height,width, label)
        

        

    
class Slider(Fl_Slider):

    def __init__(self,x,y,height,width,label="",mode="",*args):                                     #constructor of Slider class with 6 modes 

        if(mode==1):                                                                                #3 modes for horizontal slider
            Fl_Hor_Nice_Slider(x,y,height,width, label)
            
        elif(mode==2):
            Fl_Hor_Slider(x,y,height,width, label)
            
        elif(mode==3):
            Fl_Hor_Fill_Slider(x,y,height,width, label)
            
        elif(mode==4):                                                                              #3 modes for Vertical slider
            Fl_Nice_Slider(x,y,height,width, label)
            
        elif(mode==5):
            Fl_Slider(x,y,height,width, label)
            
        elif(mode==6):
            Fl_Fill_Slider(x,y,height,width, label)
            
        else:
            Fl_Hor_Nice_Slider(x,y,height,width, label)

            

class SpinBox(Fl_Counter,Fl_Roller,Fl_Dial):

    def __init__(self,x,y,height,width,label="",mode="",*args):                                     #constructor of Spinbox class with 2 modes 

        if(mode==1):                                                                                #Simple spinbox
            Fl_Simple_Counter(x,y,height,width, label)
            
        elif(mode==2):                                                                              #Special spinbox
            Fl_Counter(x,y,height,width, label)

        elif(mode==3):                                                                              #Special spinbox
            Fl_Roller(x,y,height,width, label)

        elif(mode==4):                                                                              #Special spinbox
            Fl_Dial(x,y,height,width, label)
            
        else:
            Fl_Simpler_Counter(x,y,height,width, label)



class RadioButton(Fl_Round_Button):

    def __init__(self,x,y,height,width,label="",*args):                                             #constructor of Radiobutton class
        super(RadioButton, self).__init__(x,y,height,width, label)                        
        self.type(102)







class DropDownList(Fl_Choice):

    def __init__(self,x,y,height,width,array,label="",*args):                                       #constructor of Dropbox class 
        super(DropDownList, self).__init__(x,y,height,width, label)                        

        for value in array:                                                                         #Adding value in dropbox
            self.add(value)
        
        





class CheckBox(Fl_Check_Button):

    def __init__(self,x,y,height,width,label="",*args):                                             #constructor of Checkbox class
        super(CheckBox, self).__init__(x,y,height,width, label)                       
       
 



class Button(Fl_Button):

    def __init__(self,x,y,height,width,label,mode="",*args):                                        #constructor of button class with 4 modes

        if mode==1:
            Fl_Button(x,y,height,width,label)
            
        elif mode==2:
            Fl_Return_Button(x,y,height,width,label)
            
        elif mode==3:
            Fl_Repeat_Button(x,y,height,width,label)
            
        elif mode==4:
            Fl_Light_Button(x,y,height,width,label)
            
        else:
            Fl_Button(x,y,height,width,label)
        

    
       

class TabPanel(Fl_Tabs):

    def __init__(self,x,y,height,width,*args):                                                      #constructor of tabs class
        super(TabPanel, self).__init__(x,y,height,width)                        

    def addPage(*args):
        pass

    
       
        
class GroupBox(Fl_Group):

    def __init__(self,x,y,height,width,label,*args):                                                #constructor of group class to create a frame
        super(GroupBox, self).__init__(x,y,height,width,label)   
        
        

    def setLayouts(self,*args):                                                                     #Setting frame properties and ending it        
        
        self.box(FL_THIN_UP_BOX)
        self.end()
        

class Page(Fl_Group):

    def __init__(self,x,y,height,width,label,*args):                                                #constructor of page class to create tabs
        super(Page, self).__init__(x,y,height,width,label)   
        
        

    def setPage(self,*args):                                                                        #Setting page properties and ending it        
        
        self.box(FL_THIN_UP_BOX)
        self.end()
      
      
       

 
        
class Window(Fl_Window):


    def __init__(self,height,width,label,*args):                                                    #Constructor to initiate a window
        super(Window, self).__init__(height,width,label) 
    


    def displayWindow(self,*args):                                                                  #Function to end window widgets
        
        self.show(sys.argv);                                                                        #System arguments for the window
        self.end()
        Fl.run()                                                                                    #Running program

