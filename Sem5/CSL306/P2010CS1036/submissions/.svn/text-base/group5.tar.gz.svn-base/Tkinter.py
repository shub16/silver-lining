#! /usr/bin/python
import Tkinter, sys, ttk, random, tkFont
from Tkinter import *

class Window(object):
        def __init__(self,height,width,title):
                self.window = Tk();
                self.window.title(title);
		# get screen width and height
	        ws = self.window.winfo_screenwidth();
	        hs = self.window.winfo_screenheight();
	        # calculate position x, y
	        x = (ws/2) - (width/2);  
	        y = (hs/2) - (height/2);
	        self.window.geometry('%dx%d+%d+%d' % (height, width, x, y));
		global radioVar
		radioVar = IntVar()
		return;

        def displayWindow(self, *args):
                self.window.mainloop();
                return;	

class TabPanel(ttk.Notebook, object):
	def __init__(self, x, y, height, width, parent):
		super(TabPanel, self).__init__(parent.window)
		self.pack(fill='both', expand='yes')
	
	def addPage(self, page, pageName):
		self.add(page, text = pageName)

class Page(Frame, object):
	def __init__(self, x,y,height,width,name,parent):
        	super(Page, self).__init__();
		self.configure(height = height, width = width, bd = 1, relief = SUNKEN)
		self.place(x = x, y = y);

	def setPage(self,*args):
	        pass

class GroupBox(Frame):
    def __init__(self, x,y,height,width,name,parent):
        pass

    def setLayouts(self,layoutstyle,*widgets):
        pass
	
class TextArea(Text, object):
        def __init__(self, x, y, height, width, name, parent):
		self.f = Frame(parent, height=width, width=height)
		self.f.pack_propagate(0) # don't shrink
		self.f.place(x = x, y = y)
                super(TextArea, self).__init__(self.f, bg = 'white');
		self.pack(fill = BOTH, expand = 1);

class Button(Tkinter.Button, object):
        def __init__(self, x, y, height, width, name, mode, parent):
		self.f = Frame(parent, height=width, width=height)
		self.f.pack_propagate(0) # don't shrink
		self.f.place(x = x, y = y);
		if(mode == 1):
	                super(Button, self).__init__(self.f, text = name);
		if(mode == 2):
			super(Button, self).__init__(self.f, text = name, relief = GROOVE, overrelief = RAISED);
		if(mode == 4):
			super(Button, self).__init__(self.f, text = name, relief = RIDGE);
	
		self.pack(fill = BOTH, expand = 1)

class Label(Tkinter.Label, object):
	def __init__(self, x, y, name, parent):
		super(Label, self).__init__(parent);
		self.configure(text = name);
		self.place(x = x, y = y);

class TextLine(Entry, object):
	def __init__(self, x, y, height,width,mode,name,parent):
		self.f = Frame(parent, height = width, width=height)
		self.f.pack_propagate(0) # don't shrink
		self.f.place(x = x, y = y)
		super(TextLine, self).__init__(self.f);
		if mode == "Password" or mode == "password":
			self.config(show = "*");
		self.pack(fill = BOTH, expand = 1)
				
class CheckBox(Checkbutton, object):
        def __init__(self,x,y,height,width,name,state,parent):
		self.f = Frame(parent, height = width, width = height)
		self.f.pack_propagate(0) # don't shrink
		self.f.place(x = x, y = y)
                self.CheckVar = IntVar();
		super(CheckBox, self).__init__(self.f, text = name, variable = self.CheckVar, \
                     onvalue = 1, offvalue = 0);
		self.pack(fill = BOTH, expand = 1);
                
class RadioButton(Tkinter.Radiobutton, object):
        def __init__(self,x,y,height,width,name,parent):
		self.f = Frame(parent, height = width, width = height)
		self.f.pack_propagate(0) # don't shrink
		self.f.place(x = x, y = y)
		super(RadioButton, self).__init__(self.f, text = name, variable = radioVar, value = random.randrange(0,1000));
		self.pack(fill = BOTH, expand = 1);


class DropDownList(OptionMenu, object):
        def __init__(self,x,y,height,width,List,name,parent):
		self.f = Frame(parent, height = width, width = height)
		self.f.pack_propagate(0) # don't shrink
		self.f.place(x = x, y = y)
		self.v = StringVar();
		self.v.set(name);
		super(DropDownList, self).__init__(self.f, self.v, *List );
		self.pack(fill = BOTH, expand = 1);

class Slider(Scale, object):
	def __init__(self,x,y,height,width,name,mode,minval,maxval,orientation,parent):

		if(mode==1):
			super(Slider, self).__init__(parent, length = height, width = width, from_ = minval, to = maxval);
			self.configure(orient = HORIZONTAL)
		elif(mode==2):
			super(Slider, self).__init__(parent, length = height, width = width, from_ = minval, to = maxval);
			self.configure(orient = HORIZONTAL)			
		elif(mode==3):
			super(Slider, self).__init__(parent, length = height, width = width, from_ = minval, to = maxval);
			self.configure(orient = HORIZONTAL)					
		elif(mode==4):
			super(Slider, self).__init__(parent, length = width, width = height, from_ = minval, to = maxval);
			self.configure(orient = VERTICAL)			
		elif(mode==5):
			super(Slider, self).__init__(parent, length = width, width = height, from_ = minval, to = maxval);
			self.configure(orient = VERTICAL)
		elif(mode==6):
			super(Slider, self).__init__(parent, length = width, width = height, from_ = minval, to = maxval);
			self.configure(orient = VERTICAL)

		self.place(x = x, y = y);
             		

class SpinBox(Spinbox, object):
	def __init__(self, x, y, height, width, name, mode, parent):
		self.customFont = tkFont.Font(family="Helvetica", size=12)
		self.f = Frame(parent, height = width, width = height)
		self.f.pack_propagate(0) # don't shrink
		self.f.place(x = x, y = y)
		super(SpinBox, self).__init__(self.f, font = self.customFont, from_ = 0, to = 100);
		if(mode == 1):
			self.configure(state = "readonly")			
		elif(mode == 2):
			pass
		self.pack(fill = BOTH, expand = 1);

'''----------------------------------------------------------------
	This is the exact contents of the demo file
   ----------------------------------------------------------------'''
if __name__ == '__main__':    

	dw = Window(500,400,"DEMO")
	tabWidget = TabPanel(1,1,500,400,dw)

#TextLine & TextArea Page
	textline_page = Page(50,50,400,340,"AC",tabWidget)
	textline_group = GroupBox(80,80,320,270,"TextLine",textline_page)
	t1 = TextLine(200,130,150, 30,"Normal","Name",textline_page)
	t2 = TextLine(200,180,150, 30,"Password","Password",textline_page)
	l1=Label(30,130,"Name",textline_page)
	l2=Label(30,180,"Password",textline_page)

	textarea_group = GroupBox(100,250,280,70,"TextArea",textline_page)
	t3 = TextArea(200,280,150,30,"Address",textline_page)
	l3 = Label(30,280,"Address",textline_page)
	textline_group.setLayouts("Vertical",textline_page,l1,t1,l2,t2)
	textarea_group.setLayouts("Vertical",textline_page,l3,t3)
	textline_page.setPage(textline_group,textarea_group)

#CheckBox Page
	checkbox_page = Page(50,50,400,340,"AC",tabWidget)
	checkbox = GroupBox(80,80,320,220,"CheckBoxes",checkbox_page)
	c1 = CheckBox(150,150,100,50,"CheckBox1",False,checkbox_page)
	c2 = CheckBox(150,250,100,50,"CheckBox2",False,checkbox_page)
	checkbox_group = GroupBox(50,50,400,400,"Checked CheckBoxes", checkbox_page)
	c3 = CheckBox(150,100,100,100,"CheckBox1",True,checkbox_page)
	c4 = CheckBox(150,200,100,100,"CheckBox2",True,checkbox_page)
	checkbox.setLayouts("Vertical",checkbox_page,c1,c2)
	checkbox_group.setLayouts("Vertical",checkbox_page,c3,c4)
	checkbox_page.setPage(checkbox,checkbox_group)

#Button Page
	button_page = Page(50,50,400,340,"Button",tabWidget)
	button_group = GroupBox(80,80,320,220,"Buttons",button_page)
	but1 = Button(150,100,150,50,"Normal Button",1,button_page)
	but2 = Button(150,170,150,50,"Return Button",2,button_page)
	but3 = Button(150,230,150,50,"Light Button",4,button_page)
	button_group.setLayouts("Vertical",button_page,but1,but2,but3) #Group Layout Setting
	button_page.setPage(button_group) #Page Layout Setting

#DropDownList Page
	ddl_page = Page(50,50,400,340,"DropDownList",tabWidget)
	ddl_group = GroupBox(80,80,320,220,"DropDownList",ddl_page)
	List = ["INDIA","USA","RUSSIA","CHINA","JAPAN","SOUTH AFRICA"]
	ddl = DropDownList(200,150,150,40,List,"DropDownList",ddl_page)
	l4=Label(30,150,"Address",ddl_page)
	ddl_group.setLayouts("Vertical",ddl_page,l4,ddl)
	ddl_page.setPage(ddl_group)

#Slider Page
	slider_page = Page(50,50,400,340,"Slider",tabWidget)
	slider_Hgroup = GroupBox(80,80,320,120,"Horizontal",ddl_page)
	slider1= Slider(150,95,200,20,"Naruto", 2, 0, 100, "Horizontal", slider_page)
	slider2= Slider(150,130,200,20,"Bleach", 3, 0, 200, "Horizontal", slider_page)
	slider3= Slider(150,165,200,20,"Death note", 1, 0, 150, "Horizontal", slider_page)
	slider_Hgroup.setLayouts("Vertical",slider_page,slider1,slider2,slider3)
    
	slider_Vgroup = GroupBox(80,220,320,150,"Vertical",ddl_page)
	slider4= Slider(120,240,20,100,"Code geass",4, 0, 100, "Vertical", slider_page)
	slider5= Slider(220,240,20,100,"Kenichi",5, 0, 100, "Vertical", slider_page)
	slider6= Slider(320,240,20,100,"Hitman Reborn",6, 0, 100, "Vertical", slider_page)    
	slider_Vgroup.setLayouts("Horizontal",slider_page,slider4,slider5,slider6)
    
	slider_page.setPage(slider_Hgroup,slider_Vgroup)

#RadioButton Page
	radio_page = Page(50,50,400,340,"RadioButton",tabWidget)
	radio_group = GroupBox(80,80,320,300,"RadioButton",radio_page)
	rb1 = RadioButton(150,120,100,50,"Radio Button1",radio_page)
	rb2 = RadioButton(150,200,100,50,"Radio Button2",radio_page)
	rb3 = RadioButton(150,270,100,50,"Radio Button3",radio_page)

	radio_group.setLayouts("Vertical",radio_page,rb1,rb2,rb3)
	radio_page.setPage(radio_group)


#SpinBox Page
	spinbox_page = Page(50,50,400,340,"SpinBox",tabWidget)
	spinbox_group = GroupBox(80,80,320,300,"SpinBox",spinbox_page)
	sb1 = SpinBox(110,150,230,50,"SpinBox",1,spinbox_page)
	sb2 = SpinBox(110,250,230,50,"SpinBox",2,spinbox_page)
	spinbox_group.setLayouts("Vertical",spinbox_page,sb1,sb2)
	spinbox_page.setPage(spinbox_group)


	tabWidget.addPage(checkbox_page,"CheckBox")
	tabWidget.addPage(textline_page,"TextLine")
	tabWidget.addPage(button_page,"Buttons")
	tabWidget.addPage(ddl_page,"DropDownList")
	tabWidget.addPage(slider_page,"Sliders")
	tabWidget.addPage(radio_page,"Radio Buttons")
	tabWidget.addPage(spinbox_page,"Spin Box")

#Layout setting for main display
	dw.displayWindow(tabWidget);

