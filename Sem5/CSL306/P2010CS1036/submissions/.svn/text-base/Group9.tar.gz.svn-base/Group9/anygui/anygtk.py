import gtk												# importing the module gtk
now_position=[10,10]										# defining a global variable now_position 
def default_position(x,y):									# writing a method to assign default positions to widgets
        now_position[0]=now_position[0]+x
        now_position[1]=now_position[1]+y
        return now_position

class frame(object):										# creating  frame class to create a frame in which widgets will be embeded
    parent = None 
    id=-1
    title="default title"							
    size=(600,750)
   	
    
    def __init__(self, id, title="frame",width=750, height=500):						# creating a constructor. The frame object will take 4 inoput values: id, title, width, height
        
        

        self.window = gtk.Window (gtk.WINDOW_TOPLEVEL)						# creating a frame/window
        self.window.connect("destroy", gtk.main_quit)						# connecting the destroy signal to quit method
        self.window.set_title(title)			
        											# setting frame title
        self.window.set_size_request(width,height)						# setting the size of the frame
       
        self.fixed = gtk.Fixed()								# creating a container to embed the widgets 
        self.window.add(self.fixed)
        self.fixed.show()


    def show(self):										# defining the show method which displays the window
        self.window.show()
        gtk.main()										# initialising the gtk event handling loop by calling gtk.main()
        return

    def append(self,widget):									# creating a method to add widgets to an instance of the frame. The append method takes widget as input and
        widget_type = type(widget)  								# executes the code corresponding to that widget in the following if conditions
          	
        if(isinstance(widget,button)):								# if widget type is button this if condition creates a button 
            widget.controller = gtk.Button(widget.label)
            widget.controller.set_size_request(widget.size[0],widget.size[1])
            self.fixed.put(widget.controller, widget.pos[0], widget.pos[1])            
            widget.controller.show()
            if(widget.callbackMethod != None ):
                widget.controller.connect('clicked',widget.callbackMethod)
                
        elif(isinstance(widget,text_area) ):							# if widget type is text_area this if condition creates a text_area 
            widget.controller = gtk.TextView(widget.buffer)	
            widget.controller.set_size_request(widget.size[0],widget.size[1])
            self.fixed.put(widget.controller, widget.pos[0], widget.pos[1])            
            widget.controller.show()
            if(widget.callbackMethod != None ):
                widget.controller.connect('clicked',widget.callbackMethod)
                
        elif(isinstance(widget,text_field)):							# if widget type is text_field this elseif condition creates a text_field 
            widget.controller = gtk.Entry()
            widget.controller.set_size_request(widget.size[0],widget.size[1])
            self.fixed.put(widget.controller, widget.pos[0], widget.pos[1])
            widget.controller.set_text(widget.title)            
            widget.controller.show()

        elif(isinstance(widget,check_box)):							# if widget type is check_box this elseif condition creates a check_box
            widget.controller = gtk.CheckButton(widget.label)
            widget.controller.set_size_request(widget.size[0],widget.size[1])
            self.fixed.put(widget.controller, widget.pos[0], widget.pos[1])            
            widget.controller.show()
            widget.controller.set_active(widget.value)
            
        elif(isinstance(widget,radio_buttons)):							# if widget type is radio_buttons this elseif condition creates a radiobuttons
            widget.controller = []
            radio_controller = gtk.RadioButton(None, widget.labels[0])
            radio_controller.set_size_request(widget.size[0],widget.size[1])
            self.fixed.put(radio_controller,widget.position_X[0], widget.position_Y[0])
            radio_controller.show()
           
            widget.controller.append(radio_controller)
            for i in range(1,len(widget.labels)):
                radio_controller = gtk.RadioButton(widget.controller[0], widget.labels[i])
                radio_controller.set_size_request(widget.size[0],widget.size[1])
                self.fixed.put(radio_controller,widget.position_X[i], widget.position_Y[i])
                radio_controller.show()
                widget.controller.append(radio_controller)
            
            if(widget.selected_pos != None):
                widget.controller[widget.selected_pos].set_active(True)
        elif(widget_type == "Slider" or isinstance(widget,Slider) ):
        	'''
            	frame = self.abs_frame(widget)
        	widget.instance = gtk.HScale(frame, from_=widget.start, to=widget.end , orient=root.HORIZONTAL)
       	 	widget.instance.pack(fill=root.BOTH, expand=1)
        	'''	
		adj1 = gtk.Adjustment(0.0, widget.start, widget.end, 0.1, 1.0, 1.0)
		widget.instance = gtk.HScale(adj1)
   	        widget.instance.set_size_request(widget.width,widget.height)
   	        self.fixed.put(widget.instance, widget.position_X, widget.position_Y)
            	widget.instance.show()
            	
	elif(widget_type == "SpinBox" or isinstance(widget,SpinBox) ):
		'''
       	 	frame = self.abs_frame(widget)
        	widget.instance = root.Spinbox(frame, from_=widget.start, to=widget.end )
        	widget.instance.pack(fill=root.BOTH, expand=1)
        	'''
        	
        	#adj = gtk.Adjustment(0, widget.start, widget.end, 1.0, 1.0, 0.0)
        	adj = gtk.Adjustment(0.0, widget.start, widget.end, 0.1,0.1, 0.0)
        	widget.instance = gtk.SpinButton(adj , 0.1 , 1)
        	widget.instance.set_size_request(widget.width,widget.height)
   	        self.fixed.put(widget.instance, widget.position_X, widget.position_Y)
            	widget.instance.show()    
            
        elif(isinstance(widget,combo_box)):							# if widget type is combo_box this elseif condition creates a combo_box
            widget.controller = gtk.OptionMenu()
            widget.controller.set_size_request(widget.size[0],widget.size[1])
            menu = gtk.Menu()
            #a=widget.labels[0]
            
            widget.labels.insert(0,widget.default)
            #widget.labels.append(0,widget.default)
            for name in widget.labels:
                item = gtk.MenuItem(name)
                item.show()
                menu.append(item)
               
            widget.controller.set_menu(menu)
            widget.controller.show()
            self.fixed.put(widget.controller,widget.pos[0], widget.pos[1])
        
        elif(isinstance(widget,static_text)):							# if widget type is static_text this elseif condition creates a static_text
            widget.controller = gtk.Label(widget.label)
            widget.controller.set_size_request(widget.size[0],widget.size[1])
            self.fixed.put(widget.controller, widget.pos[0], widget.pos[1])            
            widget.controller.show()
            
class static_text(object):									# creating a class for static_field widget
    controller = None
    id=-1
    pos=(200,100)
    size=(150,50)
    label="default"
    def __init__(self):
        temp=1
class button(object):										# creating a class for a button
    controller = None
    callbackMethod = None
    id=-1
    p=default_position(100,150)
    pos=(p[0],p[1])
    size=(185,35)
    label="button"
    
    def __init__(self):
        temp=1

    def onclick(self,method):									
        if(self.controller == None):
            self.callbackMethod = method
        else:
            self.controller.connect("clicked", method)
        return True
    
class text_area(object):										# creating a class for text_area
    controller = None
    callbackMethod = None
    title="this is the text area"
    p=(100,20)
    pos=(p[0],p[1])
    size=(100,100)
    buffer = gtk.TextBuffer()
    def __init__(self):
        i=1

    def set_text(self,text):
        self.buffer.set_text(text)
        return True

    def append_text(self,text):
        self.buffer.insert(self.buffer.get_end_iter(),text)
        return True              

    def clear(self):
        self.buffer.set_text("")
        return True


class Slider(object):
    instance = None
    Type = "Slider"
    def __init__(self,start,end,X,Y,width,height):
    	self.start=start
    	self.end=end
        self.position_X = X
        self.position_Y = Y
        self.width = width
        self.height = height
    def getValue(self):
    	if(self.instance == None):
    	    return ''
    	else:    
    	    return self.instance.get()
    	    
    	    
    	    
class SpinBox(object):
    instance = None
    Type = None
    def __init__(self,start,end,X,Y,width,height):
        self.type = "SpinBox"
    	self.start=start
    	self.end=end
        self.position_X = X
        self.position_Y = Y
        self.width = width
        self.height = height

    def getValue(self):
    	if(self.instance == None):
        	return ''
    	else:    
        	return str(self.instance.get_value())
            


class text_field(object):
												# creating a class for text_field
    controller = None
    title=""
    pos=(230,200)
    size=(100,100)
    
    
    def __init__(self):
        i=1

    def set_text(self,text1):
	self.controller.set_text(text1)
	return
    def get_text(self):
	self.string=self.controller.get_text()
	return self.string

class check_box(object):									# creating a class for check_box 
    controller = None
    value = False
    parent=None
    label="checkbox"
    p=default_position(150,150)
    pos=(p[0],p[1])
    size=(150,20)
    
    def __init__(self):
    	varr=1    
    
    def set_value(self,value):   								# method to set the value in the text field
        if(value != True or value != False):
            return
        if(self.controller == None):
            self.value = value
        else:
            self.controller.set_active(value)

    def get_value(self):										# method to get value from the text fiels
        if(self.controller == None):
            return self.value
        else:
            return self.controller.get_active()


class radio_buttons(object):									# creating a class for radio_buttons
    GroupController = None
    controller = None
    selected_pos = None
    total=1
    name=[]               
    label=[]
    parent=None
    pos=[]    
    size=(100,20)   
    def __init__(self):
        self.labels = []
        self.position_X = []
        self.position_Y = []
        
        self.GroupController = None

    def add_rb(self,label,X,Y):
        self.labels.append(label)
        self.position_X.append(X)
        self.position_Y.append(Y)
        return True

    def get_value(self):
        for i in range(len(self.controller)):
            if(self.controller[i].get_active()):
                return self.labels[i]
        return "None"

    def set_true(self,pos):
        if(self.controller == None):
            self.selected_pos = pos
        else:
            button_controller = self.controller[pos]
            button_controller.set_active(True)
            
            


class combo_box(object):									# creating a class for combo_box
    controller = None
    default="default"
    labels=[]
    pos=(100,200)
    size=(100,20)
    
    
    def __init__(self):
        i=0
        

    def get_value(self):
        if(self.controller == None):
            return self.value
        else:
            IntValue = self.controller.get_history()
            if(IntValue < 0):
                return None
            return self.labels[IntValue]


   
    

    
