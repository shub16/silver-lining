import sys

if __name__ == '__main__':
	x=raw_input("Enter 1 for PyGTK, 2 for PyQT, 3 for WxPython, 4 for Tkinter : ")
	if x=='1':
		from P2010CS1038_PyGTK import *
	elif x=='2':
		from P2010CS1034_PyQt import *
	elif x=='3':
		from P2010CS1067_WxPython import *
	elif x=='4':
		from P2010CS1007_Tkinter import *	
	else:
		print "Please Enter a valid number."
		sys.exit()
	
	app =App()
	frame= Windows('Image Viewer',250,250,580,620)
	
	v=Alignment(frame)
	img=image(frame)
	t1=SingleTextBox(frame,1)
	but=button(frame,'Browse')
	
	def onbrowse(event):
		d=FileDialog(frame,'Choose a file')
		filepath=d.get_value()
		t1.set_text(filepath)
		img.set_image(filepath)
	
	v.add(t1,0,1,3)
	v.add(but,0,4,1)
	v.add(img,2,1,10)

	but.bind(onbrowse)
	
	frame.show_window(v)
	
	app.loop()

