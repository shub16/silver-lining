
def main():
	x = raw_input("Enter a number from 1 to 6:\n****1 for pygtk\n****2 for pyGObject\n****3 for pyQt\n****4 for Tkinter\n****5 for wxPython\n****6 for PyFltk\n\t= ")
	x = int(x)

	if x == 1:
		import PygtkAPI as API
	elif x == 2:
		import pyGObjectAPI as API
	elif x == 3:
		import pyQtAPI as API
	elif x == 4:
		import TkInterAPI as API
	elif x == 5:
		import wxPythonAPI as API
	elif x == 6:
		import PyFltkAPI as API
	else:
		print "Enter a Valid Number" 
		return 0
	
	Students = ['Bonani Hazarika', 'Jaspreet Kaur', 'Manisha Digra',  'Manisha Dudi' ,'Tanvi Srivastava', 'Neetu Soni']

	api = API.CommonAPI("Unit Testing", 700, 700)
	path = API.CreateImage("logo.gif")
	image = api.AddImage(30,30, path)									#Image
	clok = api.CreateClock(450,10)										#Clock
	T1 = api.CreateTextBox(190,250, "FALSE")							#textbox
	L1 = api.CreateLabel(20, 250, "Enter text here: ")					#Label
	L2 = api.CreateLabel(330, 400, "Slider : ")
	S1 = api.CreateSlider(480,400)										#Slider
	L2 = api.CreateLabel(20, 350, "Buttons : ")
	B1 = api.CreateButton(190, 350, "Button1")							#Button
	B2 = api.CreateButton(350, 350, "Button2")
	L3 = api.CreateLabel(20, 400, "Spin Box : ")
	spin = api.CreateSpinButton(190,400)								#SpinButton
	L4 = api.CreateLabel(20, 450, "Progress Bar : ")
	progress = api.CreateProgressBar(190,450)							#ProgressBar
	L5 = api.CreateLabel(20, 520, "List : ")
	l = api.CreateList(190, 520, Students)								#List
	#L6 = api.CreateLabel(280, 500, "Toggle Button : ")
	toggle = api.CreateToggleButton( 550,350, "Toggle Button")			#ToggleButton
	L7 = api.CreateLabel(370, 520, "Text Area : ")
	area = api.CreateTextArea(520,520)									#TextArea
	L8 = api.CreateLabel(400, 250, "Radio Button : ")
	r = api.CreateRadioButton(600, 250, "Radio1")						#RadioButton
	L9 = api.CreateLabel(400, 280, "Check Button : ")
	c = api.CreateCheckBox(600,280, "Check")							#Checkbox
	dialog = api.CreateDialogBox("Welcome to AnyGUI \nby Group 4.\n Here is the \nDemo Window!")
																		#Dialog Box
	api.Shows()															#Show button
	
if __name__ == "__main__": main()
