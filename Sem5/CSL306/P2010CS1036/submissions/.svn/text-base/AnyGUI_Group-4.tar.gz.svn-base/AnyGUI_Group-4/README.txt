

					************* Welcome to the Project AnyGUI by Group-4 ************
					
					
					The Project incorporates 6 GUIs namely:
								pygtk
								pyGObject
								Tkinter
								pyQt
								pyFltk
								wxPython
								
					Check out the demo by using the following command:
					All the files should be in the same folder as the Main.py
					
					---->	python Main.py
					
					You can select any of the GUIs by entering the code that will be shown on your terminal
					
					Feel free to browse through the wiki page for the details about the API
					----> 	http://10.1.0.140/trac/wiki/FinalProject
					
					Also feel free to browse through the code
					
					
					**************************Thank You*******************************
					
					
					


