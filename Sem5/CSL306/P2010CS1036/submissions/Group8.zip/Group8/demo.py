#Demo application for Group-8
 
#Callback function to be called when the button is pressed
def print_button(self):
    print "Your application is created! Congrats"

def createWidgets(obj, gui):
    widgets=[]                          	  #List of widgets to be added
    obj.l1=gui.LabelWidget(obj,"Username")        #Call to the Label class that adds a staticText widget with panel as the parent
    widgets.append(obj.l1.getWidget())  	  
    obj.textbox=gui.TextLineWidget(obj)           #Call to the TextBox class that adds a single line textctrl widget with panel as the parent
    widgets.append(obj.textbox.getWidget())

    obj.l2=gui.LabelWidget(obj,"Old Password")	  #Call to the Label class that adds a staticText widget with panel as the parent
    widgets.append(obj.l2.getWidget())
    obj.pwd1=gui.PasswordFieldWidget(obj)         #call to the PasswordField class that adds a single line textctrl widget of password style with panel as the parent
    widgets.append(obj.pwd1.getWidget())

    obj.l3=gui.LabelWidget(obj,"New Password")    #Call to the Label class that adds a staticText widget with panel as the parent
    widgets.append(obj.l3.getWidget())
    obj.pwd2=gui.PasswordFieldWidget(obj)         #Call to the PasswordField class that adds a single line textctrl widget of password style with panel as the parent
    widgets.append(obj.pwd2.getWidget())

    obj.l4=gui.LabelWidget(obj,"New Password(repeat)") #Call to the Label class that adds a staticText widget with panel as the parent
    widgets.append(obj.l4.getWidget())
    obj.pwd3=gui.PasswordFieldWidget(obj)         #Call to the PasswordField class that adds a single line textctrl widget of password style with panel as the parent
    widgets.append(obj.pwd3.getWidget())

    obj.l5=gui.LabelWidget(obj,"Age")		  #Call to the Label class that adds a staticText widget with panel as the parent
    widgets.append(obj.l5.getWidget())
    obj.spinbox=gui.SpinBoxWidget(obj,18,70)      #Call to the SpinBox class that adds spinctrl widget with panel as the parent
    widgets.append(obj.spinbox.getWidget())

    obj.l6=gui.LabelWidget(obj,"Date of Birth")	  #Call to the Label class that adds a staticText widget with panel as the parent
    widgets.append(obj.l6.getWidget())
    obj.cal=gui.CalendarWidget(obj)               #Call to the Calendar widget class that adds a calendar widget with panel as the parent
    l=obj.cal.getWidget()
    for cal_widg in l:
        widgets.append(cal_widg)

    labels=["Male","Female"]
    stringname="gender"
    obj.rb=gui.RadioButtonWidget(obj,labels,stringname) #Call to the RadioButton widget class that adds list of radiobuttons with panel as the parent
    radiobuttons=obj.rb.getWidget()
    for rb in radiobuttons:
        widgets.append(rb)

    obj.l8=gui.LabelWidget(obj,"Nationality")	   #Call to the Label class that adds a staticText widget with panel as the parent
    widgets.append(obj.l8.getWidget())
    values=["Indian","British","Chinese","American","Others"]
    obj.list=gui.ListWidget(obj,values)            #Call to the List widget class that adds a combobox with list of options with panel as the parent
    widgets.append(obj.list.getWidget())

    obj.l9=gui.LabelWidget(obj,"Rating for this application")	#Call to the Label class that adds a staticText widget with panel as the parent
    widgets.append(obj.l9.getWidget())
    obj.sl=gui.SliderWidget(obj,0,10)               #Call to the Slider widget class that adds Slider ctrl widget with panel as the parent
    widgets.append(obj.sl.getWidget())
    
    obj.button=gui.ButtonWidget(obj,"Done",print_button)  #Call to the Button class that adds a button widget with panel as the parent
    widgets.append(obj.button.getWidget())           

    return widgets

def main():
	print "Choose your GUI Toolkit: \n 1. Tk\n 2. pyQT\n 3. pyGTK\n 4. wxPython\n"
	gui=raw_input()
	gui=gui.upper()
	if gui=='TK':
		import TkinterAPI as anyGUI
	elif gui=='PYQT':
		import PyQtAPI as anyGUI
	elif gui=='PYGTK':
		import PygtkAPI as anyGUI
	elif gui=='WXPYTHON':
		import wxPythonAPI as anyGUI
	else:
		print "Wrong choice!Sorry"
		return

	parent=anyGUI.setup()
	height=600				      #Height and width of the parent window
	width=400
	obj= anyGUI.WindowLayout(parent,width, height)
	widgets=createWidgets(obj, anyGUI)            #Function call to construct the widgets in the application
	obj.createLayout(widgets)		      #Function call to place the widgets in the application

if __name__ == '__main__':
	main()
