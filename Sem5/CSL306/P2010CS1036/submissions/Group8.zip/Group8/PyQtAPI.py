#!/usr/bin/python 

import os
import sys 
from PyQt4.QtCore import * 
from PyQt4.QtGui import *
from functools import partial

# function to set up the parent frame for the application
def setup():

    root = QApplication(sys.argv)
    return root

# class for the text line widget
class TextLineWidget(QWidget):

    # create the text line
    def __init__(self, parent):
	QWidget.__init__(self)
	self.widget = QLineEdit()

    # function to return the widget
    def getWidget(self):
	return self.widget
	
    # function to extract the value of the widget
    def getValue(self):
	val = self.widget.text()
	return val

# class for the text box widget
class TextBoxWidget(QWidget):

    # create the text box
    def __init__(self, parent):
	QWidget.__init__(self)
	self.widget = QTextEdit()

    # function to return the widget
    def getWidget(self):
	return self.widget
	
    # function to extract the value of the widget
    def getValue(self):
	val = self.widget.document().toPlainText()
	return val

# class for the push button widget
class ButtonWidget(QWidget):

    # create the push button
    def __init__(self, parent, name, function, *args):
	QWidget.__init__(self)
	self.widget = QPushButton(name, self)
	# call function when button in pressed
        lst = list(args)
	newlst = []
	newlst.append(self)
	for item in lst:
	    newlst.append(item)
	args = tuple(newlst)
	self.widget.clicked.connect(partial(function, *args))

    # function to return the widget
    def getWidget(self):
	return self.widget

# class for the label widget
class LabelWidget(QWidget):

    # create the label
    def __init__(self, parent, title):
	QWidget.__init__(self)
	self.widget = QLabel(title)

    # function to return the widget
    def getWidget(self):
	return self.widget

# class for the password field widget
class PasswordFieldWidget(QWidget):
    
    # create the password field
    def __init__(self, parent):
	QWidget.__init__(self)
	self.widget = QLineEdit()
	# replace characters with * in the password field
	self.widget.setEchoMode(2)

    # function to return the widget
    def getWidget(self):
	return self.widget

    # function to extract the value of the widget
    def getValue(self):
	val = self.widget.text()
	return val

# class for the spin box widget
class SpinBoxWidget(QWidget):

    # create the spin box
    def __init__(self, parent, fromvalue, tovalue):
	QWidget.__init__(self)
	self.widget = QSpinBox(self)
	self.widget.setMaximum(tovalue)
	self.widget.setMinimum(fromvalue)

    # function to return the widget
    def getWidget(self):
	return self.widget

    # function to extract the value of the widget
    def getValue(self):
	val = self.widget.value()
	return val

# class for the check box widget
class CheckBoxWidget(QWidget):

    # create the check box
    def __init__(self, parent, name):
	QWidget.__init__(self)
	self.widget = QCheckBox(name, self)

    # function to return the widget
    def getWidget(self):
	return self.widget

    # function to extract the value of the widget
    def getValue(self):
	if self.widget.isChecked():
	    return True
	else:
	    return False

# class for the radio button widget
class RadioButtonWidget(QWidget):

    # create the radio buttons
    def __init__(self, parent, labels, varname):
	QWidget.__init__(self)
	# create a group of radio buttons
	self.rbg = QButtonGroup(self)
	self.widget = []
	n = 1
	for i in labels:
	    # create a list of all radio buttons within a group
	    self.widget.append(QRadioButton(i))
	    # add all radio buttons to the group
	    self.rbg.addButton(self.widget[n-1], n)
	    n = n + 1

    # function to return the widget
    def getWidget(self):
	return self.widget

    # function to extract the value of the widget
    def getValue(self):
	b = self.rbg.checkedButton()
	if b is None:
	    return ""
	t = b.text()
	return t

# class for the list widget
class ListWidget(QWidget):
    
    # create the list
    def __init__(self, parent, values):
	QWidget.__init__(self)
	self.widget = QListWidget(self)
	# add all the values to the list
	self.widget.addItems(values)

    # function to return the widget
    def getWidget(self):
	return self.widget

    # function to extract the value of the widget
    def getValue(self):
	i = self.widget.currentItem()
	if i is None:
	    return ""
	t = i.text()
	return t

# class for the slider widget
class SliderWidget(QWidget):

    # create the slider
    def __init__(self, parent, fromvalue, tovalue):
	QWidget.__init__(self)
	self.widget = QSlider(Qt.Horizontal, self)
	self.widget.setFocusPolicy(Qt.NoFocus)
	self.widget.setMinimum(fromvalue)
	self.widget.setMaximum(tovalue)

    # function to return the widget
    def getWidget(self):
	return self.widget

    # function to extract the value of the widget
    def getValue(self):
	return self.widget.value()

# class for the calendar widget
class CalendarWidget(QWidget):

    # create the calendar
    def __init__(self, parent):
	QWidget.__init__(self)
	self.widget = []
	self.widget.append(QCalendarWidget(self))
	self.widget[0].setGridVisible(True)

    # function to return the widget
    def getWidget(self):
	return self.widget

    # function to extract the value of the widget
    def getValue(self):
	return self.widget[0].selectedDate().toString()

# class for creating the layout
class WindowLayout(QWidget): 
    def __init__(self, parent, width, height): 
        QWidget.__init__(self)
        self.frame = parent
	self.setWindowTitle('PyQt Application')

    # function that takes in a list of widgets and places them in a grid layout and displays the window on screen
    def createLayout(self, lstWidgets):
	
	layout = QGridLayout(self)
	r = 0		# r and c are used for specifying the grid in which to place the widget
        c = 0
	layout.addWidget(lstWidgets[0], r, c)	# place the first widget
	print "Added one widget"
	for wgt in lstWidgets[1:]:
	    f = int( raw_input( "Where do you want the next widget?\nSame line(1)\nNext line(2)\n" ) )		# for all the other widgets ask the user about the preferred placement
	    if f == 1:
       	        layout.addWidget(wgt, r, c+2, 2, 2)
		c = c + 2
	    else:
		c = 0
		layout.addWidget(wgt, r+2, c, 2, 2)
		r = r + 2
	    print "Added one widget"

        self.setLayout(layout)

	# show widget on screen
    	self.show()
	sys.exit(self.frame.exec_())
