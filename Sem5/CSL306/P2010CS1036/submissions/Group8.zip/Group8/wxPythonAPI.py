import wx
import wx.calendar

class WindowLayout(wx.Frame):
    def __init__(self,parent,width,height):
        wx.Frame.__init__(self, None, -1, size=(width,height))    #creating a wx.Frame widget which is parent for all other widgets. Its parent is none.
        self.panel=wx.Panel(self)                                   #creating a panel as an attribute of this frame
        self.SetTitle('WxPython Application')
        self.app=parent

    def createLayout(self,widgets):                 #to display the window after all widgets are set
        vbox = wx.BoxSizer(wx.VERTICAL)             #vertical boxSizer
        hbox = wx.BoxSizer(wx.HORIZONTAL)           #horizontal boxSizer
        i=0
        for widget in widgets:
            if i==0:
                hbox.Add(widget)                    #Adds the first widget
            else:
                print "Next widget in same line(1) or next line(2)"
                n=raw_input()
                if n=='1':                          #if in same line add to same horizontal boxSizer
                    hbox.Add(widget)
                else:                              #if to add in new line then create a new horizontal boxSize
                    vbox.Add(hbox)
                    vbox.Add((-1,10))
                    hbox=wx.BoxSizer(wx.HORIZONTAL)
                    hbox.Add(widget)
                    
            i=i+1
        vbox.Add(hbox)
        self.panel.SetSizer(vbox)                    #set the main vertical boxSizer as the sizer for the main window's panel
        self.Show()
        self.app.MainLoop()

class ButtonWidget:                                       #class to create a button widget in its constructor as an attribute
    def __init__(self,parent,name,function,*args):
        self.widget=wx.Button(parent.panel,label=name)
        self.widget.Bind(wx.EVT_BUTTON, lambda event: function(event, *args))

    def getWidget(self):                            #to return the widget
        return self.widget

class TextLineWidget:                                  #class to create a textctrl widget in its constructor as an attribute
    def __init__(self,parent):
        self.widget=wx.TextCtrl(parent.panel,-1)
        self.widget.SetInsertionPoint(0)

    def getWidget(self):                        #to return the widget
        return self.widget

    def getValue(self):                         #to get the value of the widget
        return self.widget.GetValue()

class TextBoxWidget:                                  #class to create a textctrl widget in its constructor as an attribute
    def __init__(self,parent):
        self.widget=wx.TextCtrl(parent.panel,-1,style=wx.TE_MULTILINE)
        self.widget.SetInsertionPoint(0)

    def getWidget(self):                        #to return the widget
        return self.widget

    def getValue(self):                         #to get the value of the widget
        return self.widget.GetValue()
    
class RadioButtonWidget:                              #class to create a group of radiobuttons in its constructor as an attribute
    def __init__(self,parent,labels,varName):
        radiobuttons=[]
        for l in labels:                    #labels contains the list of labels for the radiobuttons                
            rb= wx.RadioButton(parent.panel, label=l, name=varName) 
            radiobuttons.append(rb)
        self.widget=radiobuttons

    def getWidget(self):                    #to return list of radiobuttons
        return self.widget

    def getValue(self):                     #to get the label of the active radiobutton from the group
        for rb in self.widget:
            if(rb.GetValue()):
                break
        return rb.GetLabel()
        
class ListWidget:                                 #class to create a list(combobox) widget in its constructor as an attribute
    def __init__(self,parent,values):
        self.widget=wx.ComboBox(parent.panel,choices=values,style=wx.CB_READONLY)

    def getWidget(self):                    #to return the widget
        return self.widget

    def getValue(self):                     #to get the selected value from the list widget
        return self.widget.GetValue()

class PasswordFieldWidget:                        #class to create a password textctrl widget in its constructor as an attribute
    def __init__(self,parent):
        self.widget=wx.TextCtrl(parent.panel,style=wx.TE_PASSWORD)
        self.widget.SetInsertionPoint(0)

    def getWidget(self):                    #to return the widget
        return self.widget

    def getValue(self):                     #to get the value of the widget
        return self.widget.GetValue()       

class LabelWidget:                                #class to create a StaticText widget in its constructor as an attribute
    def __init__(self,parent,name):
        self.widget=wx.StaticText(parent.panel,label=name)

    def getWidget(self):                    #to return the widget
        return self.widget
        

class CheckBoxWidget:                             #class to create a checkbox widget in its constructor as an attribute
    def __init__(self,parent,name,varName):
        self.widget=wx.CheckBox(parent.panel,label=name)

    def getWidget(self):                    #to return the widget
        return self.widget

    def getValue(self):                     #to get the value of the checkbox whether True or False
        return self.widget.GetValue()

class SpinBoxWidget:                            #class to create a spinbox widget in its constructor as an attribute
    def __init__(self,parent,fromvalue,tovalue):
        self.widget=wx.SpinCtrl(parent.panel,value='')
        self.widget.SetRange(fromvalue,tovalue)

    def getWidget(self):                        #to return the widget
        return self.widget

    def getValue(self):                         #to get the value of the spinbox
        return self.widget.GetValue()

class CalendarWidget:
    def __init__(self,parent):                  #class to create a calendar widget in its constructor as an attribute
        self.widget=wx.calendar.CalendarCtrl(parent.panel)

    def getWidget(self):                        #to return the widget
        l=[]
        l.append(self.widget)
        return l

    def getValue(self):                         #to get the selected date from the calendar
        return self.widget.GetDate()

class SliderWidget:                             #class to create a slider widget in its constructor as an attribute
    def __init__(self,parent,fromvalue,tovalue):
        self.widget=wx.Slider(parent.panel,minValue=fromvalue,maxValue=tovalue,style=wx.SL_HORIZONTAL)

    def getWidget(self):                         #to return the widget
        return self.widget

    def getValue(self):                         #to get the value of the slider                         
        return self.widget.GetValue()

    
def setup():
    print "Creating a wxPython application"
    app=wx.App()
    return app
