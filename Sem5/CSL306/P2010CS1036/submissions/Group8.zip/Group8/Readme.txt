Assignment 7 : Group 8

Group members:

Ankita - P2009CS1068
Madhu Rani - P2009CS1021
Shruti Tripathi - P2009CS1101
Tania Garg - P2009CS1034

*****************************************
Instructions to run the demo application:

1. Place all five files (TkinterAPI.py, PyQtAPI.py, PygtkAPI.py, wxPythonAPI.py, demo.py) in one folder.  
2. Run the python file demo.py to see the demo application.
3. Provide the name of the GUI (tk, pyqt, pygtk, wxpython) as input when prompted.
4. It will create a sample application with widgets created within the 'createWidgets' function in demo.py

For further documentation refer to the trac page http://csl306.iitrpr.ac.in/trac/wiki/AnyGuiGroupEight

