My Assignment is on the topic "Google Page Ranking Algorithm"
I have written a five page write up on this topic and implemented the algorithm in shubham.py file.
shubham.py is a module while need a Directed Graph as an argument to the function rank()
The damping factor is taken as 0.85
The output of the following program is a dictionary with keys as nodes in the graph and corresponding values as their ranks (Sum of ranks = Total number of nodes).
