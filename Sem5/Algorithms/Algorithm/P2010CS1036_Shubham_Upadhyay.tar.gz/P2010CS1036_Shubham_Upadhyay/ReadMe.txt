My Assignment is on the topic "Google Page Ranking Algorithm"
I have written a five page write up on this topic and implemented the algorithm in shubham.py file.
shubham.py is a module while need a Directed Graph as an argument to the function rank()
The damping factor is taken as 0.85
Assumption in the implementation : (According to the Larry Page) 100 iterations would give the good approximation of the page rank of whole web
The output of the following program is a dictionary with keys as nodes in the graph and corresponding values as their ranks (Sum of ranks = Total number of nodes).
